// Grupa 13: Petar Kazic i Pavle Drobac

import java.util.Arrays;

class Player {

	private String name;
	private int x;
	private int y;
	private int width;
	private int height;
	private int health;

	public Player(String name, int x, int y, int width, int height, int health) {
		this.name = "Nepoznat igrac";
		setName(name);
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		setHealth(health);
	}

	private String srediIme(String ime) {
		String s = ime.trim();
		String rezultat = "";
		boolean pocetakRijeci = true;

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);

			if (c == ' ') {
				pocetakRijeci = true;
			} else {
				if (pocetakRijeci) {
					if (rezultat.length() > 0) {
						rezultat = rezultat + " ";
					}
					rezultat = rezultat + ("" + c).toUpperCase();
				} else {
					rezultat = rezultat + c;
				}
				pocetakRijeci = false;
			}
		}
		return rezultat;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		String sredjenoIme = srediIme(name);
		if (!sredjenoIme.equals("")) {
			this.name = sredjenoIme;
		} else {
			System.out.println("Ime igraca ne smije biti prazno.");
		}
	}

	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}

	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		if (health >= 0 && health <= 100) {
			this.health = health;
		} else {
			System.out.println("Zdravlje mora biti izmedju 0 i 100.");
		}
	}

	@Override
	public String toString() {
		return "Player[" + name + "] @ (" + x + "," + y + ") " + width + "x" + height + " HP=" + health;
	}
}

class Enemy {

	private String type;
	private int x;
	private int y;
	private int width;
	private int height;
	private int damage;

	public Enemy(String type, int x, int y, int width, int height, int damage) {
		this.type = "Nepoznat";
		setType(type);
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		setDamage(damage);
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		String sredjeniTip = type.trim();
		if (!sredjeniTip.equals("")) {
			this.type = sredjeniTip;
		} else {
			System.out.println("Tip neprijatelja ne smije biti prazan.");
		}
	}

	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}

	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		if (damage >= 0 && damage <= 100) {
			this.damage = damage;
		} else {
			System.out.println("Steta mora biti izmedju 0 i 100.");
		}
	}

	@Override
	public String toString() {
		return "Enemy[" + type + "] @ (" + x + "," + y + ") " + width + "x" + height + " DMG=" + damage;
	}
}

public class Game {

	private Player player;
	private Enemy[] enemies;
	private String[] eventLog;

	public Game(Player player) {
		this.player = player;
		this.enemies = new Enemy[0];
		this.eventLog = new String[0];
	}

	public Player dajIgraca() {
		return player;
	}

	public Enemy[] dajNeprijatelje() {
		return enemies;
	}

	public String[] dajDnevnik() {
		return eventLog;
	}

	private void dodajDogadjaj(String poruka) {
		String[] novi = Arrays.copyOf(eventLog, eventLog.length + 1);
		novi[novi.length - 1] = poruka;
		eventLog = novi;
	}

	public static boolean checkCollision(Player p, Enemy e) {
		boolean preklapanjeX = p.getX() < e.getX() + e.getWidth()
				&& p.getX() + p.getWidth() > e.getX();

		boolean preklapanjeY = p.getY() < e.getY() + e.getHeight()
				&& p.getY() + p.getHeight() > e.getY();

		return preklapanjeX && preklapanjeY;
	}

	public void decreaseHealth(Player p, Enemy e) {
		int staroZdravlje = p.getHealth();
		int novoZdravlje = staroZdravlje - e.getDamage();

		if (novoZdravlje < 0) {
			novoZdravlje = 0;
		}

		p.setHealth(novoZdravlje);

		dodajDogadjaj("UDARAC: " + p.getName() + ", neprijatelj " + e.getType() + ", steta " + e.getDamage()
				+ " -> HP " + staroZdravlje + " -> " + novoZdravlje);
	}

	public void addEnemy(Enemy e) {
		if (e != null) {
			Enemy[] novi = Arrays.copyOf(enemies, enemies.length + 1);
			novi[novi.length - 1] = e;
			enemies = novi;

			dodajDogadjaj("DODAT: " + e.getType() + " na poziciji (" + e.getX() + "," + e.getY() + ")");
		} else {
			System.out.println("Neprijatelj nije dodat jer ne postoji.");
		}
	}

	public Enemy[] findByType(String query) {
		Enemy[] rezultat = new Enemy[0];
		String trazeno = query.trim().toLowerCase();

		for (int i = 0; i < enemies.length; i++) {
			String tip = enemies[i].getType().toLowerCase();
			if (tip.contains(trazeno)) {
				rezultat = Arrays.copyOf(rezultat, rezultat.length + 1);
				rezultat[rezultat.length - 1] = enemies[i];
			}
		}
		return rezultat;
	}

	public Enemy[] collidingWithPlayer() {
		Enemy[] rezultat = new Enemy[0];

		for (int i = 0; i < enemies.length; i++) {
			if (checkCollision(player, enemies[i])) {
				rezultat = Arrays.copyOf(rezultat, rezultat.length + 1);
				rezultat[rezultat.length - 1] = enemies[i];
			}
		}
		return rezultat;
	}

	public void resolveCollisions() {
		Enemy[] sudari = collidingWithPlayer();

		dodajDogadjaj("PROVJERA: broj sudara sa igracem " + player.getName() + ": " + sudari.length);

		for (Enemy e : sudari) {
			decreaseHealth(player, e);
		}
	}

	public static Enemy napraviNeprijateljaIzTeksta(String tekst) {
		String tip = "";
		int[] brojevi = new int[5];
		int zavrsenoBrojeva = 0;
		boolean citamTip = true;
		boolean imaCifara = false;
		boolean neispravno = false;
		Enemy rezultat = null;

		for (int i = 0; i < tekst.length(); i++) {
			char c = tekst.charAt(i);

			if (citamTip) {
				if (c == ';') {
					citamTip = false;
				} else {
					tip = tip + c;
				}
			} else if (c >= '0' && c <= '9') {
				if (zavrsenoBrojeva < 5) {
					brojevi[zavrsenoBrojeva] = brojevi[zavrsenoBrojeva] * 10 + (c - '0');
					imaCifara = true;
				} else {
					neispravno = true;
				}
			} else if (c == ';' || c == ',' || c == 'x') {
				if (imaCifara) {
					zavrsenoBrojeva++;
					imaCifara = false;
				} else {
					neispravno = true;
				}
			}
		}

		if (imaCifara) {
			zavrsenoBrojeva++;
		}

		if (tip.trim().equals("")) {
			neispravno = true;
		}

		if (neispravno || zavrsenoBrojeva != 5) {
			System.out.println("Neispravan format teksta: " + tekst);
		} else {
			rezultat = new Enemy(tip, brojevi[0], brojevi[1], brojevi[2], brojevi[3], brojevi[4]);
		}
		return rezultat;
	}

	public static void ispisiNeprijatelje(Enemy[] niz) {
		if (niz.length == 0) {
			System.out.println("  (nema neprijatelja)");
		}
		for (Enemy e : niz) {
			System.out.println("  " + e);
		}
	}

	public static void main(String[] args) {

		Player igrac = new Player("   novi    igrac  ", 10, 5, 32, 32, 85);
		Game igra = new Game(igrac);

		System.out.println("Igrac: " + igrac);
		System.out.println();

		Enemy ork = new Enemy("   Orc ", 100, 100, 20, 20, 35);
		igra.addEnemy(ork);

		Enemy goblin = napraviNeprijateljaIzTeksta("Goblin;12,5;16x16;20");
		igra.addEnemy(goblin);

		System.out.println("Svi neprijatelji:");
		ispisiNeprijatelje(igra.dajNeprijatelje());
		System.out.println();

		System.out.println("Neprijatelji ciji tip sadrzi gob:");
		ispisiNeprijatelje(igra.findByType("gob"));
		System.out.println("Neprijatelji ciji tip sadrzi ORC (velika slova):");
		ispisiNeprijatelje(igra.findByType("ORC"));
		System.out.println();

		System.out.println("Neprijatelji koji se sudaraju sa igracem:");
		ispisiNeprijatelje(igra.collidingWithPlayer());
		System.out.println();

		System.out.println("Stanje igraca prije: " + igrac);
		igra.resolveCollisions();
		System.out.println("Stanje igraca poslije: " + igrac);
		System.out.println();

		System.out.println("DNEVNIK DOGADJAJA:");
		String[] dnevnik = igra.dajDnevnik();
		for (int i = 0; i < dnevnik.length; i++) {
			System.out.println("  " + (i + 1) + ". " + dnevnik[i]);
		}
	}
}
